# ProyectoFinalAlgoritmos

Juan Camilo Llanos y Felipe Guzman.

Esta es una breve presentación de nuestro proyecto final de algoritmos, el cual consiste en solucionar de una manera eficiente la problematica de contratar personas aptas para un cargo, hemos decidido hacer un programa que mediante una selección revele quienes son los que cumplen con las caracteristicas requeridas por el empleador.


